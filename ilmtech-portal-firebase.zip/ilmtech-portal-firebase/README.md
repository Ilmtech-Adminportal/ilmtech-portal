
# ILMTECH Institute Portal 🚀

An educational portal for students & faculty of ILMTECH Institute of Sciences. Built using React + Firebase + Tailwind CSS.

## 🔐 Features
- Firebase Auth (Student/Admin Login)
- Firebase Storage (File Uploads)
- Announcements Page
- Mobile Responsive
- Deployed via Netlify

## 🏫 Institute Info
- Name: ILMTECH Institute of Sciences
- Address: Batla House, Okhla
- Contact: 9917438660
- Email: ilmtechinstituteofsciences@gmail.com

## ⚙️ Setup
```bash
npm install
npm start
```

👉 Add Firebase config in `src/firebase.js`

---
