
import React from 'react';

const Announcements = () => (
  <div className="p-6">
    <h2 className="text-xl font-semibold mb-4">📢 Announcements</h2>
    <ul className="list-disc pl-6">
      <li>Admission open for new batch 2025</li>
      <li>Weekly test series begins Aug 1st</li>
      <li>Download latest syllabus from Uploads section</li>
    </ul>
  </div>
);

export default Announcements;
