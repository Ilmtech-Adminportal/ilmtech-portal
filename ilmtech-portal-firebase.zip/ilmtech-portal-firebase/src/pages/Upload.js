
import React, { useState } from 'react';
import { storage } from '../firebase';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';

const Upload = () => {
  const [file, setFile] = useState(null);
  const [progress, setProgress] = useState(0);
  const [url, setUrl] = useState('');

  const handleUpload = () => {
    const storageRef = ref(storage, `materials/${file.name}`);
    const uploadTask = uploadBytesResumable(storageRef, file);

    uploadTask.on('state_changed', 
      snapshot => {
        const prog = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
        setProgress(prog);
      }, 
      err => console.log(err),
      () => {
        getDownloadURL(uploadTask.snapshot.ref).then(url => {
          setUrl(url);
        });
      }
    );
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">Upload Study Materials</h2>
      <input type="file" onChange={(e) => setFile(e.target.files[0])} />
      <button onClick={handleUpload} className="bg-blue-600 text-white px-4 py-2 mt-2">Upload</button>
      <h4 className="mt-2">Uploaded: {progress}%</h4>
      {url && <a href={url} target="_blank" rel="noopener noreferrer">View File</a>}
    </div>
  );
};

export default Upload;
