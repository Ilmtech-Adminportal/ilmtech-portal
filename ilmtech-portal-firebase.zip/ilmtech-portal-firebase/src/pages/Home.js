
import React from 'react';

const Home = () => (
  <div className="p-6 text-center">
    <h1 className="text-3xl font-bold mb-4">Welcome to ILMTECH Institute of Sciences</h1>
    <p className="mb-2">Address: Batla House, Okhla</p>
    <p>Contact: 9917438660 | Email: ilmtechinstituteofsciences@gmail.com</p>
  </div>
);

export default Home;
