
import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav className="bg-blue-700 p-4 text-white flex justify-between flex-wrap">
      <div className="font-bold text-lg">ILMTECH Institute</div>
      <div className="space-x-4 text-sm mt-2">
        <Link to="/">Home</Link>
        <Link to="/upload">Upload</Link>
        <Link to="/login">Login</Link>
        <Link to="/admin">Admin</Link>
        <Link to="/announcements">Announcements</Link>
      </div>
    </nav>
  );
};

export default Navbar;
