import React, { useState } from 'react';

const UploadForm = ({ onUpload }) => {
  const [file, setFile] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (file) {
      onUpload(file);
      setFile(null);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-x-2">
      <input type="file" onChange={(e) => setFile(e.target.files[0])} required />
      <button className="bg-blue-600 text-white px-4 py-1 rounded">Upload</button>
    </form>
  );
};

export default UploadForm;