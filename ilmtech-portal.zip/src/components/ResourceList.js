import React from 'react';

const ResourceList = ({ resources }) => (
  <ul className="mt-4 list-disc ml-6">
    {resources.map((res, index) => (
      <li key={index}>{res}</li>
    ))}
  </ul>
);

export default ResourceList;