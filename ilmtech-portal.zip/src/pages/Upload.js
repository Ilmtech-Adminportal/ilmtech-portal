import React, { useState } from 'react';
import UploadForm from '../components/UploadForm';
import ResourceList from '../components/ResourceList';

const Upload = () => {
  const [resources, setResources] = useState([]);

  const handleUpload = (file) => {
    setResources([...resources, file.name]);
  };

  return (
    <div className="p-6">
      <h2 className="text-xl font-semibold mb-4">Upload Study Materials</h2>
      <UploadForm onUpload={handleUpload} />
      <ResourceList resources={resources} />
    </div>
  );
};

export default Upload;