import React from 'react';

const Admin = () => (
  <div className="p-6">
    <h2 className="text-xl font-semibold mb-4">Admin Dashboard</h2>
    <p>Welcome, Admin! Manage materials, users, and announcements here.</p>
  </div>
);

export default Admin;