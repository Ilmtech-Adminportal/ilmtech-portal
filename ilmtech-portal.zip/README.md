# ILMTECH Institute Portal 🌐

An educational web portal for students and teachers to manage study material, built using React.

## 🔧 Features
- Upload & access study materials
- Login for students & admins
- Admin dashboard
- Responsive design with Tailwind CSS
- Hosted on Netlify

## 🏫 Institute Details
- **Name:** ILMTECH Institute of Sciences
- **Address:** Batla House, Okhla
- **Contact:** 9917438660
- **Email:** ilmtechinstituteofsciences@gmail.com

## 🚀 Getting Started
```bash
npm install
npm start
```